#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>

// ============================================================
// Wi-Fi
// ============================================================

const char* WIFI_SSID = "Redmi Note 13 5G";
const char* WIFI_PASSWORD = "Soyyyyyy";

// ============================================================
// Pins
// ============================================================

#define TRIG_PIN 5
#define ECHO_PIN 18
#define RELAY_PIN 23

// ============================================================
// Tank geometry (PROTOTYPE — frustum shaped)
//
// Sensor is mounted 12 cm above the tank BOTTOM (i.e. 2 cm
// above the tank's top rim). Tank internal height is 10 cm.
//
//   distance == 12 cm  -> tank empty  (water height = 0 cm)
//   distance ==  2 cm  -> tank full   (water height = 10 cm)
//
// Tank is a frustum: 11 cm diameter at the top, 9 cm diameter
// at the bottom. Volume is computed with the true frustum
// formula so litres/mL readings reflect the actual shape,
// not a cylinder approximation.
// ============================================================

const float TANK_HEIGHT_CM   = 10.0;
const float SENSOR_OFFSET_CM = 12.0;              // sensor -> tank bottom
const float EMPTY_DISTANCE_CM = SENSOR_OFFSET_CM;  // 12.0
const float FULL_DISTANCE_CM  = SENSOR_OFFSET_CM - TANK_HEIGHT_CM; // 2.0

const float TOP_RADIUS_CM    = 11.0 / 2.0;  // 5.5 cm
const float BOTTOM_RADIUS_CM = 9.0 / 2.0;   // 4.5 cm

// ============================================================
// Pump thresholds — based DIRECTLY on the raw ultrasonic
// reading (distance from sensor to water surface), as
// specified for this prototype:
//
//   distance >= 7 cm  -> tank almost empty -> pump ON
//   distance <= 3 cm  -> tank almost full  -> pump OFF
//
// (this keeps the water surface cycling between 3–7 cm from
// the sensor, i.e. roughly 50%-90% full)
// ============================================================

const float PUMP_ON_DISTANCE_CM  = 7.0;
const float PUMP_OFF_DISTANCE_CM = 3.0;

// ============================================================
// Timing
// ============================================================

const unsigned long SENSOR_INTERVAL_MS = 1000;

// ============================================================
// Web server
// ============================================================

WebServer server(80);

// ============================================================
// Pump / mode state
// ============================================================

bool autoMode = true;
bool pumpState = false;

// ============================================================
// Sensor / tank values
// ============================================================

float distanceCm  = 0.0;
float heightCm     = 0.0;
float levelPercent = 0.0;   // height-based, 0-100
float volumeMl      = 0.0;  // frustum-volume based
float tankCapacityMl = 0.0; // computed once in setup()
float criticalVolumeMl = 0.0; // volume at PUMP_ON_DISTANCE_CM, computed in setup()

float previousLevelPercent = 0.0;
float previousVolumeMl     = 0.0;
float levelRatePercentPerSecond = 0.0; // for direction detection
float flowRateMlPerSec = 0.0;          // raw (signed) volume rate
float flowRateMlPerMin = 0.0;          // DISPLAY value — only non-zero while pump is filling

String direction = "Stable";
String previousDirection = "Stable";

// ============================================================
// Time prediction (hard-coded physics formulas — no ML)
// ============================================================

float timeToFullSeconds     = -1.0;
float timeToCriticalSeconds = -1.0;

// ============================================================
// Statistics
// ============================================================

float minLevelPercent = 100.0;
float maxLevelPercent = 0.0;

float sumLevelPercent = 0.0;
unsigned long levelSampleCount = 0;

unsigned long totalFillSeconds = 0;
unsigned long totalDrainSeconds = 0;

float totalFilledMl  = 0.0;
float totalDrainedMl = 0.0;

unsigned int pumpCycles  = 0;
unsigned int fillEvents  = 0;
unsigned int drainEvents = 0;

// ============================================================
// History
// ============================================================

struct HistoryPoint {
  unsigned long timeMs;
  float level;
};

const int MAX_HISTORY = 120;

HistoryPoint history[MAX_HISTORY];
int historyCount = 0;

// ============================================================
// Sensor timing
// ============================================================

unsigned long lastSensorRead = 0;
unsigned long previousSensorTime = 0;

// ============================================================
// Pump runtime
// ============================================================

unsigned long pumpStartTime = 0;
unsigned long totalPumpRuntime = 0;

// ============================================================
// Forward declarations
// ============================================================

void readUltrasonic();
void updatePump();
void setPump(bool state);
void updateHistory();
String levelStatus(float percent);

void handleRoot();
void handleStatus();
void handleHistory();
void handleMode();
void handlePump();

// ============================================================
// Ultrasonic sensor
// ============================================================

float readDistance() {

  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);

  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);

  if (duration == 0) {
    return -1.0;
  }

  return duration * 0.0343 / 2.0;
}

// ============================================================
// Frustum volume up to a given water height (mL == cm^3)
// ============================================================

float frustumVolumeMl(float h) {

  if (h <= 0.0) return 0.0;
  if (h > TANK_HEIGHT_CM) h = TANK_HEIGHT_CM;

  float r = BOTTOM_RADIUS_CM +
      (TOP_RADIUS_CM - BOTTOM_RADIUS_CM) * (h / TANK_HEIGHT_CM);

  return (PI * h / 3.0) *
      (BOTTOM_RADIUS_CM * BOTTOM_RADIUS_CM +
       BOTTOM_RADIUS_CM * r +
       r * r);
}

// ============================================================
// Tank status text
// ============================================================

String levelStatus(float percent) {

  if (percent < 5.0)   return "EMPTY";
  if (percent < 30.0)  return "LOW";
  if (percent < 90.0)  return "NORMAL";
  if (percent < 100.0) return "HIGH";

  return "FULL";
}

// ============================================================
// Read sensor, update level/volume, rate, predictions, stats
// ============================================================

void readUltrasonic() {

  float newDistance = readDistance();

  if (newDistance <= 0) {
    return;
  }

  unsigned long now = millis();

  distanceCm = newDistance;

  heightCm = EMPTY_DISTANCE_CM - distanceCm;
  if (heightCm < 0.0) heightCm = 0.0;
  if (heightCm > TANK_HEIGHT_CM) heightCm = TANK_HEIGHT_CM;

  levelPercent = (heightCm / TANK_HEIGHT_CM) * 100.0;

  volumeMl = frustumVolumeMl(heightCm);

  // ----------------------------------------------------------
  // Rate calculation
  // ----------------------------------------------------------

  if (previousSensorTime > 0) {

    float dt = (now - previousSensorTime) / 1000.0;

    if (dt > 0) {

      levelRatePercentPerSecond =
          (levelPercent - previousLevelPercent) / dt;

      flowRateMlPerSec = (volumeMl - previousVolumeMl) / dt;

      // Direction
      if (levelRatePercentPerSecond > 0.05) {

        direction = "Filling";
        totalFillSeconds += (unsigned long)dt;

      } else if (levelRatePercentPerSecond < -0.05) {

        direction = "Draining";
        totalDrainSeconds += (unsigned long)dt;

      } else {

        direction = "Stable";
      }

      // Cumulative filled/drained volume
      if (flowRateMlPerSec > 0) {
        totalFilledMl += flowRateMlPerSec * dt;
      } else if (flowRateMlPerSec < 0) {
        totalDrainedMl += (-flowRateMlPerSec) * dt;
      }
    }

  } else {

    levelRatePercentPerSecond = 0;
    flowRateMlPerSec = 0;
    direction = "Stable";
  }

  // Fill/drain event edge-detection
  if (direction != previousDirection) {

    if (direction == "Filling")  fillEvents++;
    if (direction == "Draining") drainEvents++;

    previousDirection = direction;
  }

  previousLevelPercent = levelPercent;
  previousVolumeMl = volumeMl;
  previousSensorTime = now;

  // ----------------------------------------------------------
  // Flow rate shown on the dashboard — only while the pump is
  // actively filling the tank, as specified.
  // ----------------------------------------------------------

  if (pumpState && direction == "Filling") {
    flowRateMlPerMin = flowRateMlPerSec * 60.0;
  } else {
    flowRateMlPerMin = 0.0;
  }

  // ----------------------------------------------------------
  // Statistics
  // ----------------------------------------------------------

  if (levelPercent < minLevelPercent) minLevelPercent = levelPercent;
  if (levelPercent > maxLevelPercent) maxLevelPercent = levelPercent;

  sumLevelPercent += levelPercent;
  levelSampleCount++;

  // ----------------------------------------------------------
  // Quick, hard-coded physics predictions (no ML — just
  // remaining-volume / current-rate extrapolation)
  // ----------------------------------------------------------

  timeToFullSeconds = -1.0;
  timeToCriticalSeconds = -1.0;

  if (direction == "Filling" && flowRateMlPerSec > 0.01) {

    float remainingMl = tankCapacityMl - volumeMl;

    if (remainingMl > 0) {
      timeToFullSeconds = remainingMl / flowRateMlPerSec;
    } else {
      timeToFullSeconds = 0.0;
    }
  }

  if (direction == "Draining" && flowRateMlPerSec < -0.01) {

    float aboveCriticalMl = volumeMl - criticalVolumeMl;

    if (aboveCriticalMl > 0) {
      timeToCriticalSeconds = aboveCriticalMl / (-flowRateMlPerSec);
    } else {
      timeToCriticalSeconds = 0.0;
    }
  }

  // ----------------------------------------------------------
  // History
  // ----------------------------------------------------------

  updateHistory();
}

// ============================================================
// Add point to history
// ============================================================

void updateHistory() {

  if (historyCount < MAX_HISTORY) {

    history[historyCount].timeMs = millis();
    history[historyCount].level  = levelPercent;
    historyCount++;

  } else {

    for (int i = 1; i < MAX_HISTORY; i++) {
      history[i - 1] = history[i];
    }

    history[MAX_HISTORY - 1].timeMs = millis();
    history[MAX_HISTORY - 1].level  = levelPercent;
  }
}

// ============================================================
// Relay / pump control
// ============================================================
//
// IMPORTANT:
// BC547 is acting as an inverter.
//
// ESP32 HIGH -> BC547 ON  -> Relay IN pulled LOW  -> Relay ON
// ESP32 LOW  -> BC547 OFF -> Relay IN released HIGH -> Relay OFF
//
// Therefore: HIGH = pump ON, LOW = pump OFF
// ============================================================

void setPump(bool state) {

  if (state == pumpState) return;

  pumpState = state;

  if (pumpState) {

    digitalWrite(RELAY_PIN, HIGH);
    pumpStartTime = millis();
    pumpCycles++;

    Serial.println("PUMP: ON");

  } else {

    digitalWrite(RELAY_PIN, LOW);

    if (pumpStartTime > 0) {
      totalPumpRuntime += millis() - pumpStartTime;
      pumpStartTime = 0;
    }

    Serial.println("PUMP: OFF");
  }
}

// ============================================================
// Automatic pump control — based on RAW ultrasonic distance
// ============================================================

void updatePump() {

  if (!autoMode) return;

  // Distance is LARGE when tank is nearly empty -> fill
  if (!pumpState && distanceCm >= PUMP_ON_DISTANCE_CM) {
    setPump(true);
  }

  // Distance is SMALL when tank is nearly full -> stop
  if (pumpState && distanceCm <= PUMP_OFF_DISTANCE_CM) {
    setPump(false);
  }
}

// ============================================================
// Root
// ============================================================

void handleRoot() {

  File file = LittleFS.open("/index.html", "r");

  if (!file) {
    server.send(500, "text/plain", "index.html not found");
    return;
  }

  server.streamFile(file, "text/html");
  file.close();
}

// ============================================================
// Status API
// ============================================================

void handleStatus() {

  unsigned long runtime = totalPumpRuntime;
  if (pumpState && pumpStartTime > 0) {
    runtime += millis() - pumpStartTime;
  }

  float avgLevelPercent =
      levelSampleCount > 0 ? (sumLevelPercent / levelSampleCount) : 0.0;

  String json = "{";

  json += "\"distanceCm\":" + String(distanceCm, 2) + ",";
  json += "\"heightCm\":" + String(heightCm, 2) + ",";
  json += "\"levelPercent\":" + String(levelPercent, 2) + ",";
  json += "\"volumeMl\":" + String(volumeMl, 1) + ",";
  json += "\"capacityMl\":" + String(tankCapacityMl, 1) + ",";
  json += "\"direction\":\"" + direction + "\",";
  json += "\"flowRateMlPerMin\":" + String(flowRateMlPerMin, 2) + ",";
  json += "\"pump\":" + String(pumpState ? "true" : "false") + ",";
  json += "\"mode\":\"" + String(autoMode ? "AUTO" : "MANUAL") + "\",";
  json += "\"status\":\"" + levelStatus(levelPercent) + "\",";
  json += "\"minLevelPercent\":" + String(minLevelPercent, 2) + ",";
  json += "\"maxLevelPercent\":" + String(maxLevelPercent, 2) + ",";
  json += "\"avgLevelPercent\":" + String(avgLevelPercent, 2) + ",";
  json += "\"fillEvents\":" + String(fillEvents) + ",";
  json += "\"drainEvents\":" + String(drainEvents) + ",";
  json += "\"pumpCycles\":" + String(pumpCycles) + ",";
  json += "\"pumpOnSeconds\":" + String(runtime / 1000.0, 1) + ",";
  json += "\"totalFilledMl\":" + String(totalFilledMl, 1) + ",";
  json += "\"totalDrainedMl\":" + String(totalDrainedMl, 1) + ",";
  json += "\"timeToFullSeconds\":" + String(timeToFullSeconds, 1) + ",";
  json += "\"timeToCriticalSeconds\":" + String(timeToCriticalSeconds, 1);

  json += "}";

  server.send(200, "application/json", json);
}

// ============================================================
// History API
// ============================================================

void handleHistory() {

  String json = "[";

  for (int i = 0; i < historyCount; i++) {

    if (i > 0) json += ",";

    json += "{\"t\":" + String(history[i].timeMs);
    json += ",\"level\":" + String(history[i].level, 2);
    json += "}";
  }

  json += "]";

  server.send(200, "application/json", json);
}

// ============================================================
// Mode API  (GET /api/mode?mode=AUTO|MANUAL)
// ============================================================

void handleMode() {

  if (!server.hasArg("mode")) {
    server.send(400, "text/plain", "Missing mode");
    return;
  }

  String mode = server.arg("mode");
  mode.toUpperCase();

  if (mode == "AUTO") {

    autoMode = true;
    server.send(200, "application/json", "{\"mode\":\"AUTO\"}");
    return;
  }

  if (mode == "MANUAL") {

    autoMode = false;
    server.send(200, "application/json", "{\"mode\":\"MANUAL\"}");
    return;
  }

  server.send(400, "text/plain", "Invalid mode");
}

// ============================================================
// Manual pump API  (GET /api/pump?state=ON|OFF)
// ============================================================

void handlePump() {

  if (!server.hasArg("state")) {
    server.send(400, "text/plain", "Missing state");
    return;
  }

  String state = server.arg("state");
  state.toUpperCase();

  // Manual control always forces MANUAL mode.
  autoMode = false;

  if (state == "ON") {

    setPump(true);

  } else if (state == "OFF") {

    setPump(false);

  } else {

    server.send(400, "text/plain", "Invalid state");
    return;
  }

  server.send(200, "application/json",
      pumpState ? "{\"pump\":true}" : "{\"pump\":false}");
}

// ============================================================
// Setup
// ============================================================

void setup() {

  Serial.begin(115200);
  delay(1000);

  Serial.println();
  Serial.println("==========================");
  Serial.println("      AquaSense");
  Serial.println("==========================");

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, LOW); // pump OFF at boot

  // Precompute frustum tank capacity & critical volume once
  tankCapacityMl = frustumVolumeMl(TANK_HEIGHT_CM);
  criticalVolumeMl = frustumVolumeMl(TANK_HEIGHT_CM - (EMPTY_DISTANCE_CM - PUMP_ON_DISTANCE_CM));

  Serial.print("Tank capacity (mL): ");
  Serial.println(tankCapacityMl, 1);

  if (!LittleFS.begin(true)) {
    Serial.println("LittleFS mount failed!");
  } else {
    Serial.println("LittleFS mounted.");
  }

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");

  unsigned long wifiStart = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - wifiStart < 15000) {
    delay(500);
    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED) {

    Serial.println("Wi-Fi connected!");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP());

  } else {

    Serial.println("Wi-Fi failed.");
    Serial.println("Starting AquaSense AP...");

    WiFi.mode(WIFI_AP);
    WiFi.softAP("AquaSense", "aquasense");

    Serial.print("AP IP: ");
    Serial.println(WiFi.softAPIP());
  }

  server.on("/", HTTP_GET, handleRoot);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/history", HTTP_GET, handleHistory);
  server.on("/api/mode", HTTP_GET, handleMode);
  server.on("/api/pump", HTTP_GET, handlePump);

  server.serveStatic("/style.css", LittleFS, "/style.css");
  server.serveStatic("/app.js", LittleFS, "/app.js");

  server.begin();

  Serial.println("Web server started.");
  Serial.println("Waiting for sensor data...");
}

// ============================================================
// Loop
// ============================================================

void loop() {

  server.handleClient();

  unsigned long now = millis();

  if (now - lastSensorRead >= SENSOR_INTERVAL_MS) {

    lastSensorRead = now;

    readUltrasonic();
    updatePump();

    Serial.print("Distance: ");
    Serial.print(distanceCm, 2);
    Serial.print(" cm | Level: ");
    Serial.print(levelPercent, 1);
    Serial.print("% | Volume: ");
    Serial.print(volumeMl, 1);
    Serial.print(" mL | Direction: ");
    Serial.print(direction);
    Serial.print(" | Pump: ");
    Serial.println(pumpState ? "ON" : "OFF");
  }
}