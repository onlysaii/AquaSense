// ============================================================
// AquaSense LIVE DASHBOARD
// ============================================================

let aquaSenseData = {};
let historyData = [];

let selectedRange = "LIVE";
let lastHistorySignature = "";


// ============================================================
// DOM
// ============================================================

const $ = id => document.getElementById(id);

const waterLevel = $("waterLevel");
const tankWater = $("tankWater");
const waterLitres = $("waterLitres");
const tankCapacity = $("tankCapacity");
const tankStatus = $("tankStatus");

const levelCardValue = $("levelCardValue");
const levelProgress = $("levelProgress");
const directionText = $("directionText");

const distance = $("distance");
const heightDisplay = $("heightDisplay");

const timeToFull = $("timeToFull");
const criticalPrediction = $("criticalPrediction");
const predictionNote = $("predictionNote");

const flowRate = $("flowRate");
const incomingRate = $("incomingRate");
const outgoingRate = $("outgoingRate");

const totalFilled = $("averageDaily");   // repurposed: total filled this session (mL)
const totalDrained = $("weeklyUsage");   // repurposed: total drained this session (mL)

const pumpStatus = $("pumpStatus");

const avgLevel = $("avgLevel");
const minLevel = $("minLevel");
const maxLevel = $("maxLevel");

const pumpCycles = $("pumpCycles");
const fillEvents = $("fillEvents");
const drainEvents = $("drainEvents");
const pumpRuntime = $("pumpRuntime");

const lastUpdated = $("lastUpdated");
const controlNote = $("controlNote");
const connectionText = $("connectionText");

const autoModeBtn = $("autoMode");
const manualModeBtn = $("manualMode");
const pumpOnBtn = $("pumpOn");
const pumpOffBtn = $("pumpOff");


// ============================================================
// UPDATE DASHBOARD
// ============================================================

function updateDashboard(data) {

    aquaSenseData = data;

    const level = Number(data.levelPercent) || 0;

    waterLevel.textContent = Math.round(level);
    levelCardValue.textContent = `${level.toFixed(1)}%`;

    levelProgress.style.width =
        `${Math.max(0, Math.min(100, level))}%`;

    if (tankWater) {
        tankWater.style.height = `${Math.max(0, Math.min(100, level))}%`;
    }

    // --------------------------------------------------------
    // VOLUME
    // --------------------------------------------------------

    waterLitres.textContent = `${Number(data.volumeMl || 0).toFixed(0)} mL`;

    if (tankCapacity) {
        tankCapacity.textContent = `/ ${Number(data.capacityMl || 0).toFixed(0)} mL`;
    }

    // --------------------------------------------------------
    // STATUS / DIRECTION
    // --------------------------------------------------------

    tankStatus.textContent = formatStatus(data.status);
    directionText.textContent = formatDirection(data.direction);

    // --------------------------------------------------------
    // DISTANCE
    // --------------------------------------------------------

    distance.textContent = `${Number(data.distanceCm || 0).toFixed(1)} cm`;
    if (heightDisplay) heightDisplay.textContent = `${Number(data.heightCm || 0).toFixed(1)}`;

    // --------------------------------------------------------
    // FLOW (only non-zero while pump is actively filling —
    // firmware already gates this, we just display it)
    // --------------------------------------------------------

    const flowMlPerMin = Number(data.flowRateMlPerMin || 0);

    flowRate.textContent = `${flowMlPerMin.toFixed(1)}`;
    incomingRate.textContent = `${flowMlPerMin.toFixed(1)} mL/min`;
    outgoingRate.textContent = flowMlPerMin > 0 ? "—" : "0.0 mL/min";

    // --------------------------------------------------------
    // PREDICTIONS (hard-coded physics estimate from firmware)
    // --------------------------------------------------------

    timeToFull.textContent = formatSeconds(data.timeToFullSeconds);
    criticalPrediction.textContent = formatSeconds(data.timeToCriticalSeconds);

    if (predictionNote) {
        if (data.direction === "Filling") {
            predictionNote.textContent = "Estimated from current fill rate.";
        } else if (data.direction === "Draining") {
            predictionNote.textContent = "Estimated from current drain rate.";
        } else {
            predictionNote.textContent = "Tank level is stable.";
        }
    }

    // --------------------------------------------------------
    // USAGE (session totals)
    // --------------------------------------------------------

    if (totalFilled) totalFilled.textContent = `${Number(data.totalFilledMl || 0).toFixed(0)} mL`;
    if (totalDrained) totalDrained.textContent = `${Number(data.totalDrainedMl || 0).toFixed(0)} mL`;

    // --------------------------------------------------------
    // PUMP
    // --------------------------------------------------------

    pumpStatus.textContent = data.pump ? "ON" : "OFF";

    // --------------------------------------------------------
    // STATISTICS
    // --------------------------------------------------------

    avgLevel.textContent = `${Number(data.avgLevelPercent || 0).toFixed(1)}%`;
    minLevel.textContent = `${Number(data.minLevelPercent || 0).toFixed(1)}%`;
    maxLevel.textContent = `${Number(data.maxLevelPercent || 0).toFixed(1)}%`;

    pumpCycles.textContent = data.pumpCycles ?? 0;
    fillEvents.textContent = data.fillEvents ?? 0;
    drainEvents.textContent = data.drainEvents ?? 0;

    if (pumpRuntime) {
        pumpRuntime.textContent = formatDuration(Number(data.pumpOnSeconds || 0));
    }

    // --------------------------------------------------------
    // MODE + PUMP BUTTON STATES
    // --------------------------------------------------------

    updateModeUI(data.mode, data.pump);

    // --------------------------------------------------------
    // CONNECTION
    // --------------------------------------------------------

    if (connectionText) connectionText.textContent = "Online";
    lastUpdated.textContent = "just now";
}


// ============================================================
// FORMATTING HELPERS
// ============================================================

function formatStatus(status) {

    switch (String(status || "").toUpperCase()) {
        case "EMPTY": return "Empty";
        case "LOW": return "Low";
        case "HIGH": return "High";
        case "FULL": return "Full";
        default: return "Normal";
    }
}

function formatDirection(direction) {

    switch (String(direction || "").toUpperCase()) {
        case "FILLING": return "Filling Up ↑";
        case "DRAINING": return "Draining ↓";
        default: return "Stable";
    }
}

// Seconds -> short human string. Used for the hard-coded
// quick predictions coming straight from the firmware.
function formatSeconds(seconds) {

    const value = Number(seconds);

    if (!Number.isFinite(value) || value < 0) {
        return "Stable";
    }

    if (value < 1) return "< 1s";
    if (value < 60) return `${Math.round(value)}s`;

    const minutes = Math.floor(value / 60);
    const secs = Math.round(value % 60);

    return `${minutes}m ${secs}s`;
}

function formatDuration(seconds) {

    const total = Math.max(0, Math.floor(seconds));
    const minutes = Math.floor(total / 60);
    const secs = total % 60;

    return `${minutes}m ${secs}s`;
}


// ============================================================
// FETCH CURRENT STATUS
// ============================================================

async function fetchStatus() {

    try {
        const response = await fetch("/api/status", { cache: "no-store" });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();
        updateDashboard(data);

    } catch (error) {

        console.error("Status error:", error);

        if (connectionText) connectionText.textContent = "Offline";
        lastUpdated.textContent = "connection lost";
    }
}


// ============================================================
// FETCH HISTORY
// ============================================================

async function fetchHistory() {

    try {
        const response = await fetch("/api/history", { cache: "no-store" });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const data = await response.json();

        historyData = Array.isArray(data) ? data : [];

        const signature = historyData.length === 0
            ? ""
            : `${historyData.length}-${historyData[historyData.length - 1].t}-${historyData[historyData.length - 1].level}`;

        if (signature !== lastHistorySignature) {
            lastHistorySignature = signature;
            drawGraph();
        }

    } catch (error) {
        console.error("History error:", error);
    }
}


// ============================================================
// GRAPH RANGE
// ============================================================

function getFilteredHistory() {

    if (historyData.length === 0) return [];

    if (selectedRange === "LIVE") return historyData.slice();

    const rangeMinutes = { "1H": 60, "6H": 360, "1D": 1440 }[selectedRange];

    const latestTime = historyData[historyData.length - 1].t;
    const cutoff = latestTime - (rangeMinutes * 60 * 1000);

    return historyData.filter(point => point.t >= cutoff);
}


// ============================================================
// GRAPH
// ============================================================

function drawGraph() {

    const line = document.getElementById("chartLine");
    const fill = document.getElementById("chartFill");

    if (!line || !fill) return;

    const points = getFilteredHistory();

    // No fake line — need at least two real points.
    if (points.length < 2) {
        line.setAttribute("d", "");
        fill.setAttribute("d", "");
        return;
    }

    const WIDTH = 700;
    const HEIGHT = 240;

    const chartPoints = points.map((point, index) => {

        const x = (index / (points.length - 1)) * WIDTH;

        const level = Math.max(0, Math.min(100, Number(point.level) || 0));
        const y = HEIGHT - (level / 100) * HEIGHT;

        return { x, y };
    });

    const path = createSmoothPath(chartPoints);

    line.setAttribute("d", path);
    fill.setAttribute("d", `${path} L 700 240 L 0 240 Z`);
}

function createSmoothPath(points) {

    if (points.length === 0) return "";

    if (points.length === 1) {
        return `M ${points[0].x} ${points[0].y}`;
    }

    let d = `M ${points[0].x} ${points[0].y}`;

    for (let i = 1; i < points.length; i++) {

        const previous = points[i - 1];
        const current = points[i];

        const controlX = (previous.x + current.x) / 2;

        d += ` C ${controlX} ${previous.y}, ${controlX} ${current.y}, ${current.x} ${current.y}`;
    }

    return d;
}


// ============================================================
// TIME FILTER BUTTONS
// ============================================================

document.querySelectorAll(".time-filter button").forEach(button => {

    button.addEventListener("click", () => {

        document.querySelectorAll(".time-filter button")
            .forEach(item => item.classList.remove("active"));

        button.classList.add("active");

        selectedRange = button.dataset.range || "LIVE";

        drawGraph();
    });
});


// ============================================================
// USAGE HISTORY BUTTON
// ============================================================

const usageButton = document.querySelector(".small-action");

if (usageButton) {
    usageButton.addEventListener("click", () => {
        document.querySelector(".section-card")
            ?.scrollIntoView({ behavior: "smooth" });
    });
}


// ============================================================
// MODE
// ============================================================

async function setMode(mode) {

    try {
        const response = await fetch(`/api/mode?mode=${mode}`, { cache: "no-store" });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        await fetchStatus();

    } catch (error) {
        console.error("Mode error:", error);
    }
}

autoModeBtn.addEventListener("click", () => setMode("AUTO"));
manualModeBtn.addEventListener("click", () => setMode("MANUAL"));


function updateModeUI(mode, pumpOn) {

    const current = String(mode || "AUTO").toUpperCase();
    const isManual = current === "MANUAL";

    autoModeBtn.classList.toggle("active", !isManual);
    manualModeBtn.classList.toggle("active", isManual);

    if (!isManual) {

        controlNote.textContent = "Pump is managed automatically using tank level.";

        pumpOnBtn.disabled = true;
        pumpOffBtn.disabled = true;

    } else {

        controlNote.textContent = "Manual mode is active. Use the buttons below to control the pump.";

        pumpOnBtn.disabled = false;
        pumpOffBtn.disabled = false;
    }

    // Highlight whichever circular button matches the pump's
    // ACTUAL current state (not just which one was clicked).
    pumpOnBtn.classList.toggle("engaged", !!pumpOn);
    pumpOffBtn.classList.toggle("engaged", !pumpOn);
}


// ============================================================
// PUMP (manual control)
// ============================================================

async function setPump(state) {

    if (String(aquaSenseData.mode || "").toUpperCase() !== "MANUAL") {
        return;
    }

    try {
        const response = await fetch(`/api/pump?state=${state}`, { cache: "no-store" });

        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        await fetchStatus();

    } catch (error) {
        console.error("Pump error:", error);
    }
}

pumpOnBtn.addEventListener("click", () => setPump("ON"));
pumpOffBtn.addEventListener("click", () => setPump("OFF"));


// ============================================================
// INITIALISE
// ============================================================

fetchStatus();
fetchHistory();

setInterval(fetchStatus, 1500);   // live status
setInterval(fetchHistory, 3000);  // graph history

window.addEventListener("resize", drawGraph);